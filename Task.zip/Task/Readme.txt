
Task one is in index page and task two is in books.php and there is navigation link at Book Menu available in header for books.php.Filters, pagination and limit are available in book search. The Theme is totally responsive
