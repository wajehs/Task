<footer>
	<div class="col-md-12 col-sm-12 col-12">
		<ul class="menu-list-footer text-center">
			<li class="menu-items-footer">Foobar</li>
			<li class="menu-items-footer">Uber uns</li>
			<li class="menu-items-footer">Kontakt</li>
			<li class="menu-items-footer">Impressum</li>
		</ul>
	</div>
	<div class="col-md-12 text-center copyright-div">
		&copy;Copyright 2016 Peritus Webdesign
	</div>
</footer>
