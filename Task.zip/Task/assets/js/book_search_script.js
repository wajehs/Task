function search_data(){
	var title = $("#title").val();
	var author = $("#author").val();
	var page_num= $("#page_num").val();
	var num_per_page= $("#num_per_page").val();
	$("#search_data").html('');
	$("#preloader").show();
	$.post('book_search.php',{a:title,b:author,c:page_num,d:num_per_page},function(data){
		if(data.status.trim() == "success"){
			$("#search_data").html(data.response_data);
			$("#num_per_page").val(data.limit);
			$("#page_num").html(data.page_options);
			$("#page_specs_div").show();
		}else{
			$("#page_num").html('<option value="1">1</option>');
			$("#search_data").html('<td colspan="4">No records found..</td>');
			$("#page_specs_div").hide();
		}
		$(".search-result-div").css('visibility','visible');
		$("#preloader").hide();
	},'json');
}
function close_popup(){
	$("#lightbox").hide();
}
function book_details(a,b){
	$("#preloader").show();
	if(a !=''){
		$.post('book_details.php',{a:a},function(data){
			if(data.status && data.status == 'success'){
				var img = "assets/img/book.png";
				var publisher='No records available..';
				var subject='No records available..';
				var author='No records available..';
				var publish_place="No records available..";
				if(b != ""){
					img ="http://covers.openlibrary.org/b/id/"+b+"-M.jpg"
				}
				if(data.response_data.number_of_pages){
					$("#no_page").html(data.response_data.number_of_pages);
				}else{
					$("#no_page").html('No records available..');
				}
				if(data.response_data.publishers){
					publisher ="";
					for(i=0;i<data.response_data.publishers.length;i++){
						if(i != 0) publisher+=',';
						publisher +=data.response_data.publishers[i].name;
					}
					publisher += "";
				}
				if(data.response_data.subjects){
					subject ="<div class='sub-data-div'>";
					for(i=0;i<data.response_data.subjects.length;i++){
						if(i != 0) subject+=',';
						subject +="<a href='"+data.response_data.subjects[i].url+"' target='_blank'>"+data.response_data.subjects[i].name+"</a>";
					}
					subject += "</div>";
				}
				if(data.response_data.authors){
					author ="<div class='sub-data-div'>";
					for(i=0;i<data.response_data.authors.length;i++){
						if(i != 0) author+=',';
						author +="<a href='"+data.response_data.authors[i].url+"' target='_blank'>"+data.response_data.authors[i].name+"</a>";
					}
					author += "</div>";
				}
				if(data.response_data.publish_places){
					publish_place ="<div class='sub-data-div'>";
					for(i=0;i<data.response_data.publish_places.length;i++){
						if(i != 0) publish_place+=',';
						publish_place +=data.response_data.publish_places[i].name;
					}
					publish_place += "</div>";
				}
				
				$(".book-pic").attr("src",img);
				$("#book_title").html(data.response_data.title);
				$("#book_url").attr("href",data.response_data.url);
				$("#subject_details").html(subject);
				$("#author_details").html(author);
				$("#publish_date").html(data.response_data.publish_date);
				$("#publisher_details").html(publisher);
				$("#publish_details").html(publish_place);
				$("#lightbox").show();
			}else{
				alert("Please try after sometime..");
			}
		},'json');
		$("#preloader").hide();
	}else{
		alert('Please try after sometime..');
	}
}
$('input.filter').keypress(function(e) {
  if (e.which == '13') {
     search_data();
   }
});
$(document).on('keydown', function(event) {
       if (event.key == "Escape") {
           $("#lightbox").hide();
       }
});
